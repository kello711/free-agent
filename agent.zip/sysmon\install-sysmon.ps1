$workdir = Split-Path $MyInvocation.MyCommand.Path

# Uninstall sysmon if already installed
if (Get-Service winlogbeat -ErrorAction SilentlyContinue) {
  & $workdir\sysmon.exe -u
}

& $workdir\sysmon.exe -accepteula -i $workdir\basic-config.xml
